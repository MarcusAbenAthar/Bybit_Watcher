# Esse é o __init__.py do plugins/indicadores. Ele é vazio
